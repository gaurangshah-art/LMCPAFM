LMCPAFM — QA / UAT document pack
=================================

SHARE ONLY on college-restricted storage (SharePoint, @lmcp.ac.in Drive, etc.).

Quick start for QA
------------------
1. Open 01-LMCPAFM-QA-Validation-Pack-COMBINED.md (one file with all scenarios + SOPs).
2. Use 03-UAT-Checklist-PRINT-THIS.md for pass/fail sign-off.

How to get PDF (no special software required)
---------------------------------------------
Option A — Microsoft Word (recommended)
  1. Open the .md file in Word (File → Open → select the .md file).
  2. File → Save As → PDF.

Option B — Browser
  1. Log in to LMCPAFM → SOPs & guides → open a guide → Save as PDF (Ctrl+P).

Option C — From this repo (developers)
  python scripts/export_qa_sop_pack.py --output LMCPAFM-QA-SOP-Pack.zip

Staging URL for testing: https://lmcpafm-staging.lmcp.ac.in

Generated from LMCPAFM backend Docs/ folder.
